package com.Assessment_2.dao;

import java.sql.*;


import com.Assessment_2.dbutil.DbConn;
import com.Assessment_2.pojo.Customer;

public class CustomerDetails_dao {

public  String saveCustomer(Customer Customer)
{
try
{
Connection con=DbConn.getConnection();

String sql="insert into Customer values(?,?,?,?)";

PreparedStatement stat=con.prepareStatement(sql);


stat.setString(1, Customer.getName());
stat.setString(2, Customer.getLastName());
stat.setString(3, Customer.getCustid());
stat.setString(4, Customer.getAddress());


int res= stat.executeUpdate();
if(res>0)
return "Customer details saved";


}
catch (Exception e) {
e.printStackTrace();
}

return "Cannot save Customer details";

}
}

