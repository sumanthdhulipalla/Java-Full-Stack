package com.Assessment_2.service;
import java.util.*;


import com.Assessment_2.dao.CustomerDetails_dao;
import com.Assessment_2.dao.SequenceDao;
import com.Assessment_2.pojo.Customer;


public class CustomerService {

public static void main(String[] args) {

CustomerDetails_dao dao=new CustomerDetails_dao();
Customer Customer=new Customer();
SequenceDao sequence=new SequenceDao();
String name,lastName,address;



String seq=sequence.sequenceGen();

//System.out.println(seq);


@SuppressWarnings("resource")
Scanner sc=new Scanner(System.in);
System.out.println("Enter name of Customer");
name=sc.nextLine();
System.out.println("Enter Last name of Customer");
lastName=sc.nextLine();
System.out.println("Enter address of Customer");
address=sc.nextLine();

StringBuilder Custid=new StringBuilder();
Custid.setLength(0);

Custid.append(name.charAt(0));
Custid.append(name.charAt(1));
Custid.append(lastName.charAt(0));
Custid.append(lastName.charAt(1));
Custid.append(seq);

String id=Custid.toString();
Customer.setName(name);
Customer.setLastName(lastName);
Customer.setCustid(id);
Customer.setAddress(address);


System.out.println(dao.saveCustomer(Customer));




}

}
