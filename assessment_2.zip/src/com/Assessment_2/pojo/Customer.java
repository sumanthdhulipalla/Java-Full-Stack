package com.Assessment_2.pojo;
public class Customer {

    private String name;
    private String lastName;
    private String Custid;
    private String address;
    public String getName() {
          return name;
    }
    public void setName(String name) {
          this.name = name;
    }
    public String getLastName() {
          return lastName;
    }
    public void setLastName(String lastName) {
          this.lastName = lastName;
    }
    public String getCustid() {
          return Custid;
    }
    public void setCustid(String Custid) {
          this.Custid = Custid;
    }
    public String getAddress() {
          return address;
    }
    public void setAddress(String address) {
          this.address = address;
    }
    public Customer(){}
    public Customer(String name,String lastName,String Custid,String address) {
          this.name = name;
          this.lastName = lastName;
          this.Custid = Custid;
          this.address = address;
    }
    
}

