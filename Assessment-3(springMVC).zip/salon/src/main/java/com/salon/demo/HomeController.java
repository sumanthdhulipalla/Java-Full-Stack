package com.salon.demo;

import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.salon.dao.salondao;
import com.salon.model.salon;


@Controller
public class HomeController {
	
	
	
	@InitBinder
	public void saveDateFormat(WebDataBinder binder)
	{
		SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sd,false));
	}
	
	@RequestMapping(value = "/")
	public String home(Locale locale, Model model) {
	
		return "home";
	}
	
	  @RequestMapping(value = "/bookapp") 
	  public String book(Locale locale, Model model) {
	  
	  return "book"; 
	  }
	
	  @RequestMapping(value = "/cancelapp") public String cancel(Locale locale,
	  Model model) {
	  
	  return "cancel"; }
	  
	  @RequestMapping(value = "/viewser") public String view(Locale locale, Model
	  model) {
	  
	  return "view"; }
	  
	  
	 
	
	 @Autowired 
	 salondao dao;
	  @RequestMapping(value = "/bookappointment") 
		  public String save(@ModelAttribute salon salon, BindingResult result) throws ParseException {
	
	     // System.out.println(salon.getBookingdate());     
		  
		  dao.bookapp(salon);
	  
	  return "home"; 
	  }
	  
	
	
	 @Autowired 
	 salondao salondao;
	  
	  @RequestMapping(value = "/cancelappointment") 
	  public String cancelApp(@RequestParam long phone) {
	  
	  salondao.cancelapp(phone);
	  
	  return "home"; }
	  
	  @RequestMapping(value = "/viewapp") 
	  public String viewapp(Locale locale, Model model) {
			  
			  return "viewapp"; }
	  
	 
	  
	  @RequestMapping(value = "/viewappointment") 
	  public String viewapplication(Model m,@RequestParam("phone") long phone) {
	  
	  salon phone1=salondao.viewapp(phone);
	  m.addAttribute("salon",phone1);
	  return "result"; }
	  
	  @RequestMapping(value = "/viewall")
		public String dispRestaurant(Model model) {
		ArrayList<salon> salons = salondao.dispRestaurant(); 
		model.addAttribute("salon",salons);
			return "viewall";
		}
	
}
