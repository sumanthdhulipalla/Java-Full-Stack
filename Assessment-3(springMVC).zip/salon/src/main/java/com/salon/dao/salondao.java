package com.salon.dao;

import java.sql.Date;
import java.util.ArrayList;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.salon.model.salon;

@Component
@Transactional
public class salondao {
	@Autowired
	SessionFactory sessionfactory;
	
	public void bookapp(salon salon) {
		Session session=sessionfactory.getCurrentSession();
		
		session.saveOrUpdate(salon);
	}
	public void cancelapp(long phone) {
		Session session=sessionfactory.getCurrentSession();
		salon res=(salon) session.get(salon.class, phone);
		session.delete(res);
	}
	
	public salon viewapp(long phone){
		
		Session session=sessionfactory.getCurrentSession();
		
		 salon abc=(salon) session.get(salon.class,phone);
		 
		 return abc;
	}
	public ArrayList<salon> dispRestaurant(){
		
		Session session=sessionfactory.getCurrentSession();
		
		@SuppressWarnings("unchecked")
		ArrayList<salon> salon=(ArrayList<salon>)session.createQuery("from salon").list();
			return salon ;
		}
	

}
